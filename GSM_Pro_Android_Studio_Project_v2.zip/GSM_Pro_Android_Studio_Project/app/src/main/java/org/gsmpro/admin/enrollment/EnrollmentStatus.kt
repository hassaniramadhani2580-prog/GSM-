package org.gsmpro.admin.enrollment

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.ComponentName
import org.gsmpro.admin.admin.GsmProDeviceAdminReceiver

object EnrollmentStatus {
    fun isDeviceOwner(context: Context): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isDeviceOwnerApp(context.packageName)
    }
    fun summary(context: Context): String =
        if (isDeviceOwner(context)) "Enrollment: VERIFIED • Device Owner active"
        else "Enrollment: NOT ENROLLED • Device Owner not active"

    fun adminComponent(context: Context) =
        ComponentName(context, GsmProDeviceAdminReceiver::class.java)
}
