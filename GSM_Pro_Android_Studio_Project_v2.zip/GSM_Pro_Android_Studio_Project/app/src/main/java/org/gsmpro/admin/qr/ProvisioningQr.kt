package org.gsmpro.admin.qr

/** Does not fabricate an enrollment QR: production payload needs a signed APK and verified metadata. */
object ProvisioningQr {
    fun configurationNotice(): String =
        "Package: org.gsmpro.admin\n\n" +
        "A real Setup Wizard QR requires the final signed APK, a stable HTTPS download URL, " +
        "its SHA-256 checksum, the correct admin component and valid Android provisioning extras.\n\n" +
        "A decorative/sample QR is not an enrollment token. ADB authorization is separate."
}
