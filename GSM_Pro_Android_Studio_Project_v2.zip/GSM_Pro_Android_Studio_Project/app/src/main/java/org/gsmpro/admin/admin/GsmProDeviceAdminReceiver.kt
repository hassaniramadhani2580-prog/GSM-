package org.gsmpro.admin.admin

import android.app.admin.DeviceAdminReceiver

class GsmProDeviceAdminReceiver : DeviceAdminReceiver()
