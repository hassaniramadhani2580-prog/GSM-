package org.gsmpro.admin

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeWriter
import org.gsmpro.admin.admin.GsmProDeviceAdminReceiver
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.security.MessageDigest
import android.util.Base64
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("gsmpro", Context.MODE_PRIVATE) }
    private val pickQr = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) decodeImportedQr(uri)
    }
    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); inspectFile(uri) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildHome()
    }

    private fun buildHome() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(243,246,250)) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(22,28,22,22); setBackgroundColor(Color.rgb(16,24,39))
        }
        header.addView(label("GSM PRO", 25f, Color.WHITE, true))
        header.addView(label("Professional Device Service Suite", 13f, Color.rgb(183,197,216), false))
        root.addView(header)
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16,14,16,28) }
        scroll.addView(body); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        section(body, "DEVICE OVERVIEW")
        card(body, "Device information", "${Build.MANUFACTURER} ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nBuild: ${Build.DISPLAY}\nHardware: ${Build.HARDWARE}\nFingerprint: ${Build.FINGERPRINT}")
        val stat = StatFs(Environment.getDataDirectory().absolutePath)
        val total = stat.totalBytes / (1024*1024*1024)
        val free = stat.availableBytes / (1024*1024*1024)
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val battery = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        card(body, "Live device status", "Battery: ${if (battery in 0..100) "$battery%" else "Unavailable"}\nInternal storage: ${total-free} GB used / $total GB total\nFree storage: $free GB\nDevice Owner: ${if (isDeviceOwner()) "ACTIVE" else "Not enrolled"}")

        section(body, "ENROLLMENT & ADMIN")
        action(body, "GSM Pro QR Setup", "Generate only after the signed APK URL and SHA-256 are configured") { qrSetup() }
        action(body, "Alliance Shield QR — Play Store", "Show the original Play Store enrollment QR selected from your screenshot") { showAllianceShieldQr() }
        action(body, "Owner/Admin status", "Check Android's actual Device Owner state") { showOwnerStatus() }
        action(body, "Open Android setup settings", "Open system settings; no hidden ADB approval") {
            runCatching { startActivity(Intent(Settings.ACTION_SETTINGS)) }.onFailure { toast("Settings could not be opened") }
        }

        section(body, "REPAIR & ANALYSIS")
        action(body, "Partition / Image Inspector", "Select a file to inspect its name, size and detected header") { pickFile.launch(arrayOf("*/*")) }
        action(body, "Hex & Binary Viewer", "Open a file and view a read-only hexadecimal preview") { pickFile.launch(arrayOf("*/*")) }
        action(body, "Chipset & Device Database", "Show chipset identity reported by Android; unknown values stay unknown") { showChipset() }
        action(body, "Professional Service Center", "Create and view local repair work-order notes") { serviceCenter() }

        section(body, "FIRMWARE CENTER — VERIFIED STATUS")
        card(body, "Samsung firmware", "Package recognition: not implemented in this build\nOdin / Download Mode flashing: NOT AVAILABLE\nNo flash button is shown.")
        card(body, "Unisoc / SPD", "PAC parsing and device flashing: NOT AVAILABLE\nNo BROM/EDL or authorization bypass functions.")
        card(body, "MediaTek / Qualcomm", "Scatter / firehose parsing and flashing: NOT AVAILABLE\nRequires model-specific validation and authorized tooling.")

        section(body, "TOOLS STATUS")
        card(body, "ADB / Fastboot", "ADB host authorization cannot be granted by this app. No shell execution is advertised.\nFastboot terminal: not implemented.")
        card(body, "Boot Image Analyzer", "Basic file/header inspection is available through the Image Inspector. Full boot image unpacking is not implemented.")
        card(body, "ADB Script Manager", "Not implemented — intentionally no inactive or pretend execution button.")
        setContentView(root)
    }

    private fun label(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text=s; textSize=size; setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun section(parent: LinearLayout, text: String) { parent.addView(TextView(this).apply { this.text=text; textSize=11f; setTextColor(Color.rgb(86,103,126)); setTypeface(typeface,1); setPadding(4,18,4,8) }) }
    private fun card(parent: LinearLayout, title: String, detail: String) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,14,16,14); setBackgroundColor(Color.WHITE) }
        box.addView(label(title,16f,Color.rgb(25,38,57),true))
        box.addView(TextView(this).apply { text=detail; textSize=13f; setTextColor(Color.rgb(79,94,116)); setPadding(0,7,0,0) })
        val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=9; parent.addView(box,lp)
    }
    private fun action(parent: LinearLayout, title: String, detail: String, click: () -> Unit) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,14,16,14); setBackgroundColor(Color.WHITE); isClickable=true; isFocusable=true }
        box.addView(label(title,16f,Color.rgb(25,38,57),true))
        box.addView(TextView(this).apply { text=detail; textSize=12f; setTextColor(Color.rgb(90,106,128)); setPadding(0,5,0,0) })
        box.setOnClickListener { click() }
        val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=9; parent.addView(box,lp)
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    private fun isDeviceOwner() = getSystemService(DEVICE_POLICY_SERVICE).let { (it as DevicePolicyManager).isDeviceOwnerApp(packageName) }

    private fun showOwnerStatus() {
        val dpm=getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val active=dpm.isAdminActive(android.content.ComponentName(this,GsmProDeviceAdminReceiver::class.java))
        val owner=dpm.isDeviceOwnerApp(packageName)
        android.app.AlertDialog.Builder(this).setTitle("GSM Pro enrollment status")
            .setMessage("Device Owner: ${if(owner) "CONFIRMED" else "NO"}\nDevice Admin active: ${if(active) "YES" else "NO"}\n\nThese values come from Android DevicePolicyManager.")
            .setPositiveButton("OK",null).show()
    }

    private fun qrSetup() {
        val url=prefs.getString("apk_url","") ?: ""
        val hash=prefs.getString("apk_hash","") ?: ""
        val msg=if(url.startsWith("https://") && hash.matches(Regex("(?i)[0-9a-f]{64}")))
            "APK URL and checksum are configured. Android provisioning extras still require final DPC validation before a production QR can be generated."
        else "GSM Pro QR is NOT READY. A real signed APK HTTPS download URL and its exact SHA-256 checksum are required. This app will not create a fake QR."
        val dialog=android.app.AlertDialog.Builder(this).setTitle("GSM Pro QR provisioning")
            .setMessage(msg).setPositiveButton(if(url.startsWith("https://") && hash.matches(Regex("(?i)[0-9a-f]{64}"))) "Generate QR" else "Configure") { _,_->
                if(url.startsWith("https://") && hash.matches(Regex("(?i)[0-9a-f]{64}"))) showProvisioningQr(url,hash) else configureProvisioning()
            }.setNegativeButton("Close",null).create()
        dialog.show()
    }

    private fun showProvisioningQr(url:String, shaHex:String) {
        try {
            val digest=shaHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
            val checksum=Base64.encodeToString(digest, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            val payload="""{"android.app.extra.PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME":"org.gsmpro.admin/org.gsmpro.admin.admin.GsmProDeviceAdminReceiver","android.app.extra.PROVISIONING_DEVICE_ADMIN_PACKAGE_DOWNLOAD_LOCATION":"$url","android.app.extra.PROVISIONING_DEVICE_ADMIN_PACKAGE_CHECKSUM":"$checksum"}"""
            val matrix=QRCodeWriter().encode(payload,BarcodeFormat.QR_CODE,900,900)
            val bmp=Bitmap.createBitmap(900,900,Bitmap.Config.ARGB_8888)
            for(y in 0 until 900) for(x in 0 until 900) bmp.setPixel(x,y,if(matrix[x,y]) Color.BLACK else Color.WHITE)
            val image=ImageView(this).apply { setImageBitmap(bmp); adjustViewBounds=true; setPadding(12,12,12,12) }
            val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; addView(image,LinearLayout.LayoutParams(-1,760)); addView(TextView(this@MainActivity).apply { text="QR payload is generated from the saved APK URL and checksum. Test on a factory-reset test device before deployment."; textSize=12f; setPadding(12,8,12,8) }) }
            android.app.AlertDialog.Builder(this).setTitle("GSM Pro Device Owner QR").setView(box).setPositiveButton("Close",null).show()
        } catch(e:Exception) { toast("QR could not be generated: ${e.message}") }
    }

    private fun configureProvisioning() {
        val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,8,20,0) }
        val url=EditText(this).apply { hint="Signed APK HTTPS URL"; setText(prefs.getString("apk_url","")); inputType=android.text.InputType.TYPE_TEXT_VARIATION_URI }
        val hash=EditText(this).apply { hint="APK SHA-256 (64 hex characters)"; setText(prefs.getString("apk_hash","")) }
        layout.addView(url); layout.addView(hash)
        android.app.AlertDialog.Builder(this).setTitle("GSM Pro provisioning details").setView(layout)
            .setPositiveButton("Save") { _,_->
                val u=url.text.toString().trim(); val h=hash.text.toString().trim()
                if(!u.startsWith("https://") || !h.matches(Regex("(?i)[0-9a-f]{64}"))) toast("Invalid URL or SHA-256; not saved")
                else { prefs.edit().putString("apk_url",u).putString("apk_hash",h).apply(); toast("Provisioning details saved; QR still needs validated Android extras") }
            }.setNegativeButton("Cancel",null).show()
    }

    private fun showAllianceShieldQr() {
        val image = ImageView(this).apply {
            setImageResource(R.drawable.alliance_shield_playstore_qr)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(8, 8, 8, 8)
        }
        val note = TextView(this).apply {
            text = "Alliance Shield — Play Store edition\nQR extracted from the first code in the screenshot you supplied. The QR payload was decoded and identifies com.rrivenllc.shieldx with the official shieldx_install.apk URL. This is Alliance Shield's own enrollment QR, not a GSM Pro QR. Successful enrollment still depends on Android setup state and current service availability."
            textSize = 13f
            setTextColor(Color.rgb(65, 78, 98))
            setPadding(16, 8, 16, 16)
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(ScrollView(this@MainActivity).apply { addView(image) }, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(note)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Alliance Shield — Play Store QR")
            .setView(content)
            .setPositiveButton("Close", null)
            .show()
    }

    private fun decodeImportedQr(uri:Uri) {
        try {
            val bmp=contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) } ?: throw Exception("Image could not be read")
            val pixels=IntArray(bmp.width*bmp.height); bmp.getPixels(pixels,0,bmp.width,0,0,bmp.width,bmp.height)
            val source=RGBLuminanceSource(bmp.width,bmp.height,pixels)
            val result=MultiFormatReader().decode(BinaryBitmap(HybridBinarizer(source))).text
            prefs.edit().putString("alliance_qr_payload",result).apply()
            android.app.AlertDialog.Builder(this).setTitle("Imported QR payload")
                .setMessage("QR decoded successfully. Payload is stored locally as reference only.\n\n${result.take(1200)}\n\nThis does not prove Alliance Shield enrollment will succeed.")
                .setPositiveButton("OK",null).show()
        } catch(e:Exception) { toast("No readable QR code found in that image. Nothing was saved.") }
    }

    private fun inspectFile(uri:Uri) {
        try {
            val name=uri.lastPathSegment ?: "Selected file"
            val bytes=contentResolver.openInputStream(uri).use { stream ->
                val out=ByteArrayOutputStream(); val buffer=ByteArray(8192); var remaining=65536
                while(remaining>0) { val n=stream!!.read(buffer,0,minOf(buffer.size,remaining)); if(n<=0) break; out.write(buffer,0,n); remaining-=n }
                out.toByteArray()
            }
            val magic=when {
                bytes.size>=8 && String(bytes,0,8,Charsets.US_ASCII)=="ANDROID!" -> "Android boot image header (ANDROID!)"
                bytes.size>=8 && String(bytes,0,8,Charsets.US_ASCII)=="VNDRBOOT" -> "Vendor boot image header"
                bytes.size>=4 && bytes[0]==0x3a.toByte() && bytes[1]==0xff.toByte() -> "Possible sparse image header"
                else -> "Unknown / not identified"
            }
            val hex=bytes.take(128).joinToString(" ") { "%02X".format(it) }
            android.app.AlertDialog.Builder(this).setTitle("Read-only file inspection")
                .setMessage("Name: $name\nBytes read for preview: ${bytes.size}\nHeader: $magic\n\nHex preview (first 128 bytes):\n$hex")
                .setPositiveButton("OK",null).show()
        } catch(e:Exception) { toast("Could not read selected file: ${e.message}") }
    }

    private fun showChipset() {
        val hardware=Build.HARDWARE ?: "unknown"
        val product=Build.PRODUCT ?: "unknown"
        val soc=if(Build.VERSION.SDK_INT>=31) Build.SOC_MODEL else "Not exposed on this Android version"
        android.app.AlertDialog.Builder(this).setTitle("Device / chipset report")
            .setMessage("Manufacturer: ${Build.MANUFACTURER}\nModel: ${Build.MODEL}\nProduct: $product\nHardware: $hardware\nSoC model: $soc\n\nAndroid-reported identifiers only. If Android does not expose the chipset, GSM Pro will not guess.")
            .setPositiveButton("OK",null).show()
    }

    private fun serviceCenter() {
        val input=EditText(this).apply { hint="Customer / device / repair notes"; minLines=3; setText(prefs.getString("work_orders","")) }
        android.app.AlertDialog.Builder(this).setTitle("Service Center — local work notes").setView(input)
            .setPositiveButton("Save") { _,_-> prefs.edit().putString("work_orders",input.text.toString()).apply(); toast("Work notes saved on this device") }
            .setNegativeButton("Cancel",null).show()
    }
}
