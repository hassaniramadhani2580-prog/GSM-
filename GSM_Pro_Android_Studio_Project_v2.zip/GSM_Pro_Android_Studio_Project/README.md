# GSM Pro — Android Studio source project

Package: `org.gsmpro.admin`  
Language: Kotlin  
Minimum Android: 6.0 (API 23)  
Compile/Target SDK: 35

## Implemented in this source build

- Live device overview from Android `Build`, `StatFs`, and `BatteryManager` APIs.
- Device Owner and Device Admin state checks using `DevicePolicyManager`.
- GSM Pro Android Enterprise provisioning QR generation **only after** an HTTPS APK URL and a 64-character SHA-256 checksum are configured. The QR payload contains the standard DPC component, package download URL, and URL-safe Base64 package checksum.
- Alliance Shield QR image import and decoding using ZXing. The decoded payload is stored locally as reference text; this does not certify that Alliance Shield enrollment will succeed.
- Read-only file inspection through Android's Storage Access Framework, including basic Android boot/vendor_boot magic detection and a bounded hex preview.
- Android-reported chipset/device identifiers. Unknown values are not guessed.
- Local service-center work notes saved on the device.

## Explicitly not implemented (no fake controls)

- Samsung Odin/Download Mode flashing.
- Unisoc/SPD PAC flashing.
- MediaTek scatter flashing.
- Qualcomm/firehose/EDL flashing.
- Full boot image unpack/repack, partition writing, NV/modem operations.
- ADB shell execution, silent ADB authorization, Fastboot terminal, BROM/EDL access or security bypass.
- ADB Script Manager and full multi-user/cloud service-center backend.

These workflows require model-specific, authorized tooling and real-device validation. They are intentionally not represented as working features.

## Build

Open this folder in Android Studio (Giraffe or newer), install Android SDK 35, use JDK 17, sync Gradle, then Build > Build APK(s).

There is no prebuilt APK in this archive. This environment did not run an Android SDK/Gradle build, so compilation and device behavior still need verification in Android Studio.

## Device Owner QR requirements

1. Build and sign the exact GSM Pro APK that will be installed.
2. Host that APK at a stable HTTPS URL.
3. Calculate SHA-256 over the exact APK bytes and enter the 64-character hexadecimal digest.
4. Generate the QR in GSM Pro.
5. Test Android Enterprise provisioning on an authorized, factory-reset test device. Device Owner can only be provisioned in supported setup flows; installing the app normally does not make it Device Owner.

ADB host trust is separate from Device Owner enrollment. This app cannot silently approve an ADB RSA host.

## Alliance Shield QR note

The two previously supplied image files were not machine-decodable as QR codes in this build preparation, so their payloads are not hard-coded. Use **Alliance Shield QR > Import** with a clear, valid QR image. GSM Pro will show the exact decoded payload or report that no QR was found.
