# Feature truth table

| Feature | Status in this source archive |
|---|---|
| Device overview | Implemented (Android APIs) |
| Device Owner status | Implemented (actual DPM check) |
| Device Admin receiver | Declared; activation/provisioning must be tested |
| GSM Pro provisioning QR | Implemented generator; requires signed APK URL + exact SHA-256; real enrollment needs test |
| Alliance Shield QR | Image import/decode implemented; supplied images could not be decoded during preparation |
| Basic image/partition header inspection | Implemented, read-only and limited |
| Hex preview | Implemented, read-only, first 64 KiB read / first 128 bytes displayed |
| Chipset identification | Android-reported identifiers only; may be unknown |
| Service-center notes | Local notes implemented |
| Samsung / Unisoc / MTK / Qualcomm flashing | Not implemented |
| ADB / Fastboot command execution | Not implemented |
| Full boot image analysis | Not implemented |

## Alliance Shield QR image update (2026-10-31)
- Added the first QR from the user's supplied screenshot as `drawable-nodpi/alliance_shield_playstore_qr.png`.
- The second QR labelled SHIELD RED was intentionally excluded.
- The selected QR was decoded and its payload identifies package `com.rrivenllc.shieldx` and the official `shieldx_install.apk` download URL.
- The app now displays this selected QR directly in the Alliance Shield section. It remains Alliance Shield's own enrollment QR, not a GSM Pro provisioning QR; current enrollment success is not guaranteed.
